﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using dependencyInjectionDemo.Models;
using dependencyInjectionDemo.Repositories.Implementations;
using dependencyInjectionDemo.Repositories.Interfaces;

namespace dependencyInjectionDemo.Controllers
{
    public class StudentController : Controller
    {
       // private DependencyDemoContext db = new DependencyDemoContext();
        private readonly IUnitOfWork unitOfWork;
        private readonly IStudentRepository studentRepository;
        private readonly ICourseRepository courseRepository;
        //public StudentController()   //uncomment this to implement unit of work 
        //{
        //    unitOfWork = new UnitOfWork();
        //}

        public StudentController(IStudentRepository _studentRepository, ICourseRepository _courseRepository, IUnitOfWork _unitOfWork)
        {
            unitOfWork = _unitOfWork;
            studentRepository = _studentRepository;
            courseRepository = _courseRepository;

        }

        public ActionResult Index()
        {
            //var students = db.Students.Include(s => s.Cours);
            //var students = unitOfWork.Repository<Student, int>().GetAllEntity();
            var students = studentRepository.GetAllEntity();
            return View(students.ToList());
        }

        public ActionResult Details(int id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            //Student student = db.Students.Find(id);
            //Student student = unitOfWork.Repository<Student, int>().GetEntityById(id);
            Student student = studentRepository.GetEntityById(id);
             if (student == null)
            {
                return HttpNotFound();
            }
            return View(student);
        }

        public ActionResult Create()
        {
            //ViewBag.StudentCourse = new SelectList(db.Courses, "CourseID", "CourseName");
           // ViewBag.StudentCourse = new SelectList(unitOfWork.Repository<Cours, int>().GetAllEntity(), "CourseID", "CourseName");
            ViewBag.StudentCourse = new SelectList(courseRepository.GetAllEntity(), "CourseID", "CourseName");
            return View();
        }
       
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "StudentID,StudentName,StudentCourse")] Student student)
        {
            if (ModelState.IsValid)
            {
               // db.Students.Add(student);
                //db.SaveChanges();
               // unitOfWork.Repository<Student, int>().AddEntity(student);
               studentRepository.AddEntity(student);
                unitOfWork.SaveChanges();
                return RedirectToAction("Index");
            }

           // ViewBag.StudentCourse = new SelectList(db.Courses, "CourseID", "CourseName", student.StudentCourse);
            //ViewBag.StudentCourse = new SelectList(unitOfWork.Repository<Cours, int>().GetAllEntity(), "CourseID", "CourseName", student.StudentCourse);
            ViewBag.StudentCourse = new SelectList(courseRepository.GetAllEntity(), "CourseID", "CourseName", student.StudentCourse);
            return View(student);
        }
       
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            //Student student = db.Students.Find(id);
            Student student = unitOfWork.Repository<Student, int>().GetEntityById(id.Value);
            if (student == null)
            {
                return HttpNotFound();
            }
            //ViewBag.StudentCourse = new SelectList(db.Courses, "CourseID", "CourseName", student.StudentCourse);
            ViewBag.StudentCourse = new SelectList(unitOfWork.Repository<Cours, int>().GetAllEntity(), "CourseID", "CourseName", student.StudentCourse);
            return View(student);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "StudentID,StudentName,StudentCourse")] Student student)
        {
            if (ModelState.IsValid)
            {
                //db.Entry(student).State = EntityState.Modified;
                //db.SaveChanges();
                //unitOfWork.Repository<Student, int>().UpdateEntity(student);
                Student studentToUpdate = studentRepository.GetEntityById(student.StudentID, includeProperties: "Cours", filter: d => d.StudentID == student.StudentID);
                studentToUpdate.StudentName = student.StudentName;
                studentToUpdate.StudentCourse = student.StudentCourse;
                studentRepository.UpdateEntity(studentToUpdate);
                unitOfWork.SaveChanges();
                return RedirectToAction("Index");
            }
            //ViewBag.StudentCourse = new SelectList(db.Courses, "CourseID", "CourseName", student.StudentCourse);
            //ViewBag.StudentCourse = new SelectList(unitOfWork.Repository<Cours, int>().GetAllEntity(), "CourseID", "CourseName", student.StudentCourse);
            ViewBag.StudentCourse = new SelectList(courseRepository.GetAllEntity(), "CourseID", "CourseName", student.StudentCourse);
            return View(student);
        }

        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            //Student student = db.Students.Find(id);
            //Student student = unitOfWork.Repository<Student, int>().GetEntityById(id.Value);
            Student student = studentRepository.GetEntityById(id.Value);
            if (student == null)
            {
                return HttpNotFound();
            }
            return View(student);
        }
       
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            //Student student = db.Students.Find(id);
            //db.Students.Remove(student);
           // Student student = unitOfWork.Repository<Student, int>().GetEntityById(id);
            Student student = studentRepository.GetEntityById(id);
            //unitOfWork.Repository<Student, int>().DeleteEntity(id);
            studentRepository.DeleteEntity(id);
            //db.SaveChanges();
            unitOfWork.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                //db.Dispose();
                unitOfWork.Dispose();
            }
            unitOfWork.Dispose(disposing);
        }
    }
}
