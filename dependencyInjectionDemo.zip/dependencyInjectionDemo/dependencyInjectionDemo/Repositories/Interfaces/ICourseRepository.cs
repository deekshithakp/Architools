﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using dependencyInjectionDemo.Models;

namespace dependencyInjectionDemo.Repositories.Interfaces
{
    public interface ICourseRepository:IGenericRepository<Cours,int>
    {
        //if there is any custom methods for the particualr table then declare it here
    }
}
