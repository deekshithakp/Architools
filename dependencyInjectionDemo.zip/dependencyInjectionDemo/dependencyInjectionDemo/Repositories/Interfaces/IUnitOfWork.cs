﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dependencyInjectionDemo.Repositories.Interfaces
{
    public interface IUnitOfWork:IDisposable
    {
        void SaveChanges();
        IGenericRepository<T, Tkey> Repository<T, Tkey>() where T : class;
        void Dispose(bool disposing);
    }
}
