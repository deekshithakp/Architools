﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace dependencyInjectionDemo.Repositories.Interfaces
{
    public interface IGenericRepository<T, Tkey>  where T : class
    {
        //returntype function_name parameters
        IEnumerable<T> GetAllEntity();
        T GetEntityById(Tkey keyValue);
        T GetEntityById(Tkey KeyValue, string includeProperties = "", Expression<Func<T, bool>> filter = null);
        void AddEntity(T tObject);
        void UpdateEntity(T tObject);
        void DeleteEntity(Tkey keyValue);
        void DeleteEntity(T tObject);
        

    }
   
}
