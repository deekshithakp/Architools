﻿using dependencyInjectionDemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dependencyInjectionDemo.Repositories.Interfaces
{
   public interface IStudentRepository : IGenericRepository<Student , int>
    {
       //if there is any custom methods for the particualr table then declare it here
    }
}
