﻿using dependencyInjectionDemo.Models;
using dependencyInjectionDemo.Models.ContextManager;
using dependencyInjectionDemo.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace dependencyInjectionDemo.Repositories.Implementations
{
    public class StudentRepository : GenericRepository<Student, int>, IStudentRepository
    {
        //if there are any other methods other than common methods define it here

        #region variables
        private DependencyDemoContext Context = default(DependencyDemoContext);

        #endregion

        #region Constructor

        public StudentRepository()
        {
            //Context = new DependencyDemoContext();
            Context = ContextManager.getContext();
        }
        #endregion

    }
}