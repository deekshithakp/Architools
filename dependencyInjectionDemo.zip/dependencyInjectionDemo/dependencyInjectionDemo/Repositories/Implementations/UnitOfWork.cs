﻿using dependencyInjectionDemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using dependencyInjectionDemo.Repositories.Interfaces;
using System.Data.Common;
using dependencyInjectionDemo.Models.ContextManager;
using System.Data.Entity.Core.Objects;
using System.Data;

namespace dependencyInjectionDemo.Repositories.Implementations
{
    public class UnitOfWork:IUnitOfWork
    {
        private DependencyDemoContext context = default(DependencyDemoContext);
        public Dictionary<Type, object> repositories = new Dictionary<Type, object>();
        private bool disposed = false;

        public UnitOfWork()
        {
            context = new DependencyDemoContext();
            //context = ContextManager.getContext();

        }

        public IGenericRepository<T, Tkey> Repository<T, Tkey>() where T : class  //for generic unit of work and generic repository
        {
            if (repositories.Keys.Contains(typeof(T)) == true)
            {
                return repositories[typeof(T)] as IGenericRepository<T, Tkey>;
            }
            IGenericRepository<T, Tkey> repo = new GenericRepository<T, Tkey>(context);
            repositories.Add(typeof(T), repo);
            return repo;
        }

        public void SaveChanges()
        {
           context.SaveChanges();
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        public virtual void Dispose(bool disposing)
        {
             if (!this.disposed)
             {
                 if (disposing)
                 {
                     this.context.Dispose();
                 }
             }
             this.disposed = true;
        }

       
    }
}