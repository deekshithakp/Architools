﻿using dependencyInjectionDemo.Models;
using dependencyInjectionDemo.Models.ContextManager;
using dependencyInjectionDemo.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.Entity;

using System.Data.Entity.Validation;
using System.Diagnostics;
using System.Linq;
using System.Linq.Expressions;
using System.Web;

namespace dependencyInjectionDemo.Repositories.Implementations
{
    public class GenericRepository<T, Tkey> : IGenericRepository<T, Tkey> where T : class
    {
        #region variables
        private DependencyDemoContext Context = default(DependencyDemoContext);
        DbSet<T> dbSet;


        #endregion

        #region Constructor
        public GenericRepository(DependencyDemoContext _context) //for generic repository and generic unit of work
        {
            this.Context = _context;
            this.dbSet = _context.Set<T>();
        }

        public GenericRepository()
        {
            //Context = new DependencyDemoContext();
            Context = ContextManager.getContext();
            dbSet = Context.Set<T>();
            
        }
        #endregion




        public IEnumerable<T> GetAllEntity()
        {
            return dbSet.ToList();

        }

        public T GetEntityById(Tkey keyValue)
        {
            return dbSet.Find(keyValue);

        }


        public T GetEntityById(Tkey keyValue, string includeProperties = "", Expression<Func<T, bool>> filter = null)
        {
            IQueryable<T> query = dbSet;
            // db.IDetails.Include(c => c.IDetailIpadOsvers).Where(i => i.IdetailID == id).Single();
            foreach (var includeProperty in includeProperties.Split
                (new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))      //to include foreign keys
            {
                query = query.Include(includeProperty);
            }

            if (filter != null)        // for search functionality
            {
                query = query.Where(filter);
            }
            return query.Single();

        }

        public void AddEntity(T tObject)
        {

            dbSet.Add(tObject);
            Context.SaveChanges();

        }

        public void UpdateEntity(T tObject)
        {
            try
            {
                if (tObject == null)
                {
                    throw new ArgumentNullException("entity");
                }
                //this.Context.Entry(tObject).State = EntityState.Modified;   //not working with dependency injection
                this.Context.SaveChanges();
            }
            catch (DbEntityValidationException dbEx)
            {
                var msg = string.Empty;
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        msg += Environment.NewLine + string.Format("Property: {0} Error: {1}",
                        validationError.PropertyName, validationError.ErrorMessage);
                    }
                }
                Debug.WriteLine(msg);
                var fail = new Exception(msg, dbEx);
                throw fail;
            }
        }


        public void DeleteEntity(Tkey id)
        {
            T entityToDelete = dbSet.Find(id);
            DeleteEntity(entityToDelete);
        }

        public void DeleteEntity(T tObject)
        {

            try
            {
                if (tObject == null)
                {
                    throw new ArgumentNullException("entity");
                }
                this.dbSet.Remove(tObject);
                this.Context.SaveChanges();
            }
            catch (DbEntityValidationException dbEx)
            {
                var msg = string.Empty;

                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        msg += Environment.NewLine + string.Format("Property: {0} Error: {1}",
                        validationError.PropertyName, validationError.ErrorMessage);
                    }
                }
                var fail = new Exception(msg, dbEx);
                throw fail;
            }


        }
    }
}