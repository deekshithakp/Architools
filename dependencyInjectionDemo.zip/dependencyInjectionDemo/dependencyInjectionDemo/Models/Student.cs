using System;
using System.Collections.Generic;

namespace dependencyInjectionDemo.Models
{
    public partial class Student
    {
        public int StudentID { get; set; }
        public string StudentName { get; set; }
        public Nullable<int> StudentCourse { get; set; }
        public virtual Cours Cours { get; set; }
    }
}                         