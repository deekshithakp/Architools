using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace dependencyInjectionDemo.Models.Mapping
{
    public class StudentMap : EntityTypeConfiguration<Student>
    {
        public StudentMap()
        {
            // Primary Key
            this.HasKey(t => t.StudentID);

            // Properties
            this.Property(t => t.StudentName)
                .HasMaxLength(50);

            // Table & Column Mappings
            this.ToTable("Students");
            this.Property(t => t.StudentID).HasColumnName("StudentID");
            this.Property(t => t.StudentName).HasColumnName("StudentName");
            this.Property(t => t.StudentCourse).HasColumnName("StudentCourse");

            // Relationships
            this.HasOptional(t => t.Cours)
                .WithMany(t => t.Students)
                .HasForeignKey(d => d.StudentCourse);

        }
    }
}
