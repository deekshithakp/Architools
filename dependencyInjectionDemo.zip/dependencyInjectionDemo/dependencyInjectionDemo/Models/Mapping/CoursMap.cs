using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace dependencyInjectionDemo.Models.Mapping
{
    public class CoursMap : EntityTypeConfiguration<Cours>
    {
        public CoursMap()
        {
            // Primary Key
            this.HasKey(t => t.CourseID);

            // Properties
            this.Property(t => t.CourseName)
                .HasMaxLength(50);

            // Table & Column Mappings
            this.ToTable("Courses");
            this.Property(t => t.CourseID).HasColumnName("CourseID");
            this.Property(t => t.CourseName).HasColumnName("CourseName");
        }
    }
}
