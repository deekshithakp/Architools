﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace dependencyInjectionDemo.Models.ContextManager
{
    public class ContextManager
    {
        private static DependencyDemoContext objContext = default(DependencyDemoContext);
        private readonly static object objDummy = new object();
        private ContextManager()
        {

        }
        public static DependencyDemoContext getContext()              //return a instance of the db
        {
            if (objContext == null)
            {
                lock (objDummy)
                {
                    if (objContext == null)
                        objContext = new DependencyDemoContext();
                }
            }

            return objContext;
        }
    }
}