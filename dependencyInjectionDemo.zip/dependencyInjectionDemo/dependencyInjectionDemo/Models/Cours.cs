using System;
using System.Collections.Generic;

namespace dependencyInjectionDemo.Models
{
    public partial class Cours
    {
        public Cours()
        {
            this.Students = new List<Student>();
        }

        public int CourseID { get; set; }
        public string CourseName { get; set; }
        public virtual ICollection<Student> Students { get; set; }
    }
}
