using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using dependencyInjectionDemo.Models.Mapping;

namespace dependencyInjectionDemo.Models
{
    public partial class DependencyDemoContext : DbContext
    {
        static DependencyDemoContext()
        {
            Database.SetInitializer<DependencyDemoContext>(null);
        }

        public DependencyDemoContext()
            : base("Name=DependencyDemoContext")
        {
        }

        public DbSet<Cours> Courses { get; set; }
        public DbSet<Student> Students { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Configurations.Add(new CoursMap());
            modelBuilder.Configurations.Add(new StudentMap());
        }
    }
}
